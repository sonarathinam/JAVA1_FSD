package Classandobject;
	public class Test  
	{ 
	    public static void main(String[] args) 
	    { 
	        Shape s1 = new Circle("Black", 5.8); 
	        Shape s2 = new Rectangle("Green", 2, 8);
	        System.out.println(s1.toString()); 
	        System.out.println(s2.toString()); 
	    } 



}
