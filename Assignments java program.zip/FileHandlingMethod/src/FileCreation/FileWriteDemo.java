package FileCreation;
import java.io.FileWriter;
//import java.util.*;
public class FileWriteDemo
{
	public static void main(String args[]) {
		String data= "12,sona , 5647, EEE, Chennai location, India.";
	
	
	try {
	FileWriter output= new FileWriter("D:\\Data.txt");
	output.write(data);
	System.out.println("File Written Successfully");
	output.close();
	}
	catch(Exception e)
	{
		System.out.println("Error File: "+ e);
	}
}
}
