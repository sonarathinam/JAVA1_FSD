package Classandobject;


	public class GFG { 
		public static void main(String[] args) { 
		    //creating instance of Account class 
		    Account acc=new Account(); 
		    //setting values through setter methods 
		    acc.setAcc_no(23568978451L); 
		    acc.setName("Madan"); 
		    acc.setEmail("madan234@gmail.com"); 
		    acc.setAmount(25000f); 
		    //getting values through getter methods 
		    System.out.println(acc.getAcc_no()+" "+acc.getName()+" "+acc.getEmail()+" "+acc.getAmount()); 
		} 
		}

	
