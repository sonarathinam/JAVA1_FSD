package Hashmap;
import java.util.*;


public class ABC {

 
 public static void main(String[] args)
 {

     
     Map<String, Integer> map = new HashMap<>();

     
     map.put("shalini", 450);
     map.put("ram", 70);
     map.put("maria", 67);

     for (Map.Entry<String, Integer> e : map.entrySet())

        
         System.out.println(e.getKey() + " "
                            + e.getValue());
 }
}

