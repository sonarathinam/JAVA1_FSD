package Hashmap;


	import java.util.*;
	  
	// Main class
	public class JKL {
	  
	    // Main driver method
	    public static void main(String[] args)
	    {
	  
	        // Creating an empty TreeMap
	        Map<String, Integer> map = new TreeMap<>();
	  
	        // Inserting custom elements in the Map
	        // using put() method
	        map.put("ANIL", 78);
	        map.put("SANA", 45);
	        map.put("RAJ", 67);
	  
	        // Iterating over Map using for each loop
	        for (Map.Entry<String, Integer> e : map.entrySet())
	  
	            // Printing key-value pairs
	            System.out.println(e.getKey() + " "
	                               + e.getValue());
	    }
	}

