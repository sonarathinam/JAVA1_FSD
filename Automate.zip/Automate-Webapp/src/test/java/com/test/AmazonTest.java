package com.test;

import org.testng.annotations.Test;

public class AmazonTest {
  @Test
  public void Test() {
	  System.out.println("Test Using TestNG");
  }
}
