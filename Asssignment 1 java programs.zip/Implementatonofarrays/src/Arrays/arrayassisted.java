package Arrays;

public class arrayassisted {
	public static void main(String[] args) {
	int a[]= {67,45,78,23,12};
	for(int i=0;i<5;i++) {
	System.out.println("Elements of array a: "+a[i]);
	int[][] b = { {6, 5, 3, 7}, {4, 8, 12} };
      
      System.out.println("\nLength of row 1: " + b[0].length);
      }
}
}


	



