package insertandremove;
import java.util.*;
public class insertandremovequeue {
	public static void main(String[] args)
	        throws IllegalStateException
	    {
	  
	        
	        Queue<Integer> Q
	            = new LinkedList<Integer>();
	  
	       
	        Q.add(58);
	        Q.add(78);
	        Q.add(451);
	        Q.add(102);
	  
	       
	        System.out.println("Queue: " + Q);
	  
	        
	        System.out.println("Queue's head: " + Q.remove());
	  
	        
	        System.out.println("Queue's head: " + Q.remove());
	    }
	}


