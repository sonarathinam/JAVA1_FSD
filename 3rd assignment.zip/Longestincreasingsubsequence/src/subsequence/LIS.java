package subsequence;
	class LIS {
	    static int lis(int arr[], int n)
	    {
	        int lis[] = new int[n];
	        int l, m, max = 0;
	        for (l = 0; l < n; l++)
	            lis[l] = 1;
	        for (l = 1; l < n; l++)
	            for (m = 0; m < l; m++)
	                if (arr[l] > arr[m] && lis[l] < lis[m] + 1)
	                    lis[l] = lis[m] + 1;
	        for (l = 0; l < n; l++)
	            if (max < lis[l])
	                max = lis[l];
	 
	        return max;
	    }
	 
	    public static void main(String args[])
	    {
	        int arr[] = { 3,10,7,9,21,19 };
	        int n = arr.length;
	        System.out.println("Length of lis is " + lis(arr, n) + "\n");
	    }
	}
	
	