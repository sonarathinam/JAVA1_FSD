package FileCreation;
import java.io.File;  
public class FileDeleteDemo  
{  
public static void main(String[] args)  
{     
try  
{         
File f= new File("D:\\Data.txt");          
if(f.delete())                       
{  
System.out.println(f.getName() + " deleted");  
}  
else  
{  
System.out.println("failed");  
}  
}  
catch(Exception e)  
{  
e.printStackTrace();  
}  
}  
}  