
public class MAIN {

	public static void main(String[] args) {
		shirt s = new shirt();
		s.setcolor("white");
		s.setsize('M');
		s.putOn();
		System.out.println(s.color);
		System.out.println(s.size);
		

	}

}
